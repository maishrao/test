package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Client;

import com.cg.service.IQueryService;

@Controller
public class QueryController
{
	@Autowired
	private IQueryService iQueryService;
	
	
	@RequestMapping("/index")
	public String getHomepage(Model model) {
		model.addAttribute("clientList",iQueryService.loadAll());
		model.addAttribute("client",new Client());
		return "index";
	}
	
	
	 @RequestMapping(value="save",method=RequestMethod.POST)
	public String save(@ModelAttribute("client") Client client,Model model) {
		client=iQueryService.save(client);
		model.addAttribute("message","client with Id"+client.getQueryId()+"added succesfully!");
	
		return "answer";
	}
	
	
	
	@RequestMapping("/search")
	public String search(@ModelAttribute("client")Client client,Model model ) {
      client=iQueryService.search(client);
      model.addAttribute("solutionGivenBy",new String[]{"Uma","Rahul","kavita","Hema"});
		model.addAttribute(client);
		System.out.println(client);
		return "search";
	}
	
	@RequestMapping("/update")
	public String update(@ModelAttribute("client")Client client,BindingResult result,Model model ) {
		
		if(result.hasErrors())
		{
			return "failure";
		}
		else
		{
		iQueryService.update(client);
		return "success";
	}       
	}
	
}

package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.entities.Client;



@Repository
public class IQueryDAOImpl implements IQueryDAO
{
	@PersistenceContext
    private EntityManager entityManager;

	@Override
	public Client save(Client client) {
		entityManager.persist(client);
		entityManager.flush();
	
		return client;
	}

	@Override
	public List<Client> loadAll() {
		TypedQuery<Client> query= entityManager.createQuery("Select e from Client e",Client.class);
		return query.getResultList();
	
	}

	@Override
	public Client search(Client client) {
		client=entityManager.find(Client.class, client. getQueryId());
		
		return client;
	}

	@Override
	public void update(Client client) {
		// TODO Auto-generated method stub
		Client client1=entityManager.find(Client.class, client. getQueryId());
		client1.setQueryRaisedBy(client.getQueryRaisedBy());
		
		
	}
	
	
	
}

package com.cg.dao;

import java.util.List;

import com.cg.entities.Client;

public interface IQueryDAO {


	public abstract	Client save(Client client);
	
	public abstract List<Client>loadAll();
	
public abstract Client search(Client client);
public abstract void update(Client client);


}

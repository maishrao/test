package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.IQueryDAO;
import com.cg.entities.Client;

@Service
@Transactional
public class IQueryServiceimpl implements IQueryService
{

	@Autowired
	private IQueryDAO iQueryDAO;
	
	@Override
	public Client save(Client client) {
		// TODO Auto-generated method stub
		return iQueryDAO.save(client);
	}

	@Override
	public List<Client> loadAll() {
		// TODO Auto-generated method stub
		return iQueryDAO.loadAll(); 
	}

	@Override
	public Client search(Client client) {
		// TODO Auto-generated method stub
		return iQueryDAO.search(client);
	}

	@Override
	public void update(Client client) {
		// TODO Auto-generated method stub
		iQueryDAO.update(client);
	}

}
